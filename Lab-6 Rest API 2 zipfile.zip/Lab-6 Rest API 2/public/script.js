document.addEventListener('DOMContentLoaded', () => {
    const taskListElement = document.getElementById('task-list');
    const addTaskForm = document.getElementById('add-task-form');
  
    // Function to fetch tasks from the server
    const fetchTasks = async () => {
      try {
        const response = await fetch('/tasks');
        if (!response.ok) {
          throw new Error(`Failed to fetch tasks. Status: ${response.status}`);
        }
        const tasks = await response.json();
        displayTasks(tasks);
      } catch (error) {
        console.error(error);
        alert('Failed to fetch tasks. Please try again.');
      }
    };
  
    // Function to display tasks in the DOM
    const displayTasks = (tasks) => {
      taskListElement.innerHTML = '';
  
      tasks.forEach((task) => {
        const taskElement = document.createElement('div');
        taskElement.classList.add('task');
        taskElement.innerHTML = `
          <h3>${task.title}</h3>
          <p>${task.description}</p>
          <button onclick="editTask(${task.id})">Edit</button>
          <button onclick="deleteTask(${task.id})">Delete</button>
        `;
        taskListElement.appendChild(taskElement);
      });
    };
  
    // Function to handle task deletion
    window.deleteTask = async (taskId) => {
      try {
        const response = await fetch(`/tasks/${taskId}`, { method: 'DELETE' });
  
        if (!response.ok) {
          throw new Error(`Failed to delete task. Status: ${response.status}`);
        }
  
        fetchTasks();
      } catch (error) {
        console.error(error);
        alert('Failed to delete task. Please try again.');
      }
    };
  
    // Function to handle task editing (placeholder, you can implement a form for editing)
    window.editTask = (taskId) => {
      alert(`Editing task with ID: ${taskId}`);
    };
  
    // Event listener for the add task form
    addTaskForm.addEventListener('submit', async (event) => {
      event.preventDefault();
  
      const formData = new FormData(addTaskForm);
      const title = formData.get('title');
      const description = formData.get('description');
  
      try {
        // Send a POST request to add a new task
        const response = await fetch('/tasks', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ title, description }),
        });
  
        if (!response.ok) {
          throw new Error(`Failed to add task. Status: ${response.status}`);
        }
  
        fetchTasks();
        addTaskForm.reset();
      } catch (error) {
        console.error(error);
        alert('Failed to add task. Please try again.');
      }
    });
  
    // Fetch tasks when the page loads
    fetchTasks();
  });
  